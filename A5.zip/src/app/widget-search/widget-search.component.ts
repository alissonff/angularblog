import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget-search',
  templateUrl: './widget-search.component.html',
  styleUrls: ['./widget-search.component.css']
})
export class WidgetSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
